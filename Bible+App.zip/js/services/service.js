/*
 * Service settings
 */
var DailyVerse = {}
var Settings = {}

/*
 * Services
 */

GenericService = new Apperyio.GenericService({

    "serviceName": "GenericService"

    ,
    'defaultRequest': {
        "data": null
    }
});